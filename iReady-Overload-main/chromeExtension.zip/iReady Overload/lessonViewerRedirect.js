
	location.href = `chrome-extension://${chrome.runtime.id}/lessonViewer.html`;